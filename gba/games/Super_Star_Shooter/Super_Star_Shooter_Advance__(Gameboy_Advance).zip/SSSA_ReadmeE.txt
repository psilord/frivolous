
##############################################################

    Project CYPRUS.
      Super Star Shooter Advance (aka. 'SSSA').

                           Apr05,2003 (C)The DOTMAP BORTHERS.
                                     Website MAGiC TOUCH,AND.

##############################################################

Thank you for purchasing the "SUPER STAR SHOOTER ADVANCE"!
 ...purchasing?  it's NOT for sale, don't worry :) 
"SUPER STAR SHOOTER" is originally developed by 
The DOTMAP BROTHERS for SHARP X68000 Personal workstation
in 1991.  I, AND(and@big.or.jp), ported the software for
Nintendo Game Boy Advance after 12 years since then.
Though I said "ported", it is not a work referring to
the original source but just following the game appearance
played by myself.
So, it's contains several defferent features from original.
Please understand the situation beforehand, thank you.

##############################################################
    Environment of operation 
##############################################################

    - Emulator
    �EWindowsXP / VisualBoyAdvance v1.4
    �EWindowsXP / BoycottAdvance v0.2.7

    - Original System
    �ENintendo GamyBoyAdvance    + FLASH Advance Pro 256M
    �ENintendo GamyBoyAdvance SP + FLASH Advance Pro 256M
    �ENintendo GamyBoyAdvance    + XG-Flash 256M
    �ENintendo GamyBoyAdvance SP + XG-Flash 256M

!caution! It doesn't mean to assure the all operations
under the same situation.

##############################################################
    Manual 
##############################################################

--------------------------------------------------------------
    2 MINUTES GAME
--------------------------------------------------------------

Play for the highest score during 2 minutes.

Default Key assign:

	stick -- direction
	A button -- back fire ( and speed control )
	B button -- shot ( attack )
    start button -- game start/pause

"Back fire" can both control the speed(3step) and attack enemies.  

You can break red circle objects on the ground and get power up items.
You would be strengthened and got barrier by those items
for 5 escalations.
If you are powered up enough already, take more items and you
can use "all crash" --- sweap out the enemies on the screen.

You also can break blue circle objects on the fround
and get bonus items.
You would get higher score by taking them.

There are some more hidden bonus. Please try to find them all!

--------------------------------------------------------------
    SCORE RANKING
--------------------------------------------------------------
    Show you the top 10 scores.

--------------------------------------------------------------
    STAFF LIST
--------------------------------------------------------------
    STAFF LIST :)

--------------------------------------------------------------
    OPTION
--------------------------------------------------------------

    Sound Test
    left,right -- select the sound
    A button -- play
    B button -- stop

    Sound Volume Control
    left,right -- Set the volume level.

    DIPSWITCH
    left,right -- Select the Dipswitch
    A or B button -- ON/OFF Dipswitch

              DipSwitch
          -----------------
        A |7|6|5|4|3|2|1|0|
          -----------------
        B |7|6|5|4|3|2|1|0|
          -----------------

        A7/B7/B5/B4/B2/B0 are not used now, 
        but they might be extensioned in the future.


        A6:Old Type Gage
          Chanege the speed gage as same as the X68k version.
          Interface will be simple.

        A5:BtSwap Shot&BackFire
          Swap the functions of A and B button.

        A4:R-Bt Assigned B-Bt
          Let R button do the same function as B button.

        A3:L-Bt VSync Skip
          Use L button and it won't wait V-Sync. (for Debug)

        A2:No Sound Output
           It won't output the sounds.

        A1:Quick Reset(LRAB-Bt)
          Quick reset will be enabled.
          Push L + R + A + B button at the same time.

        A0:Invincibility
        �@You will be invincible.  But the score won't be counted.

        B6:SRAM Reset A
        B3:SRAM Reset B
        B1:SRAM Reset C
        �@If you set these 3 bits on, all the SRAM data
          ( DipSwitch data, SCORE data and so on) will be erased. 
          For security reason, this option needs 3 bits change.
          SRAM reset won't be done until you restart the machine or 
          do soft reset.  Please be aware of using this option.

        *tips
            I recommend to set A4/A1 option on.
            The playability will be more comfortable and
            quick start will be enabled.


        SELECT + START bring OPTION MODE to an end.

##############################################################
    etc.
##############################################################

    SOFT RESET
        SELECT + START do soft reset.
        (except OPTION MODE)

    REPLAY
        Wait for a moment with TITLE. Your data will
        be replayed.

    SAVE
        Cases of AUTO SAVE
            �Eat the first boot.
            �Eat the end of OPTION MODE
            �EGAME OVER/TIME OUT

        !CAUTION!
        DO NOT power off the machine at those time.
        Your save data might be lost and the game won't be
        reboot the worst case.

        When you get the highest score, your play data
        will be saved on SRAM.


##############################################################
    Thanks
##############################################################

This game is created by these tools below.
I want to give my best regards to the authors of them.

-----------
http://devkitadv.sourceforge.net/index.html
DevKit Advance
    GCC and other ... Development kit.

-----------
http://mind.riot.org/krawall/
Krawall Advance(Non-Commercial Version)
    Sound Driver

-----------
http://vboy.emuhq.com/
    Game boy advance Emulator

-----------
http://homepage3.nifty.com/taka7646/taka/
TEdit v0.31
    16(256)Color Bitmap Editor

-----------
http://www.din.or.jp/~rimass/
ORE MAP EDITOR ED-OMP-4B
    MAP Editor

-----------
http://www.geocities.com/kaleid_gba/
Kaleid 1.2.4
    Graphic Converter

-----------
http://users.raketnet.nl/darkfader/http://darkfader.net/gba/
Bin2o
    Binary to Object File Converter

-----------
http://www.modplug.com/
Modplug Tracker
    S3M Music Data Create

-----------
http://www.ipc-tokai.or.jp/~ytanaka/
XM6
    SHARP X68000 Emulator #1

-----------
http://www.geocities.co.jp/SiliconValley-Sunnyvale/1779/
WinX68kHighSpeed
    SHARP X68000 Emulator #2

-----------
http://www.ksky.ne.jp/~yamama/
EX68
    SHARP X68000 Emulator #3

-----------
http://j-gbadev.hp.infoseek.co.jp/
GBA Programming Laboratory
    I referred to some texts.

-----------
http://vsync.org/
Suzume Aikoukai
    I referred to some texts.


##############################################################

The Master Tiny TOMO -- who is the programmer of the
original SSS for X68000

 --- thank you very much for accepting my offer
     for porting SSS to GBA!

-----------
http://www4.big.or.jp/~macgyver/
The Master Tiny TOMO's WebSite


##############################################################

I appriciate you opinion and impressions!
...well, but please write in Japanese, if possible :-P

website MAGiC TOUCH
http://www10.big.or.jp/~and/
mailto:and@big.or.jp

Copyright 1991,2003 The DOTMAP BROTHERS.



--------------------
English translation was Miyuki Oku. Thank you very much.
